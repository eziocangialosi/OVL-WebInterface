<?php
    $API_link = "https://api.ovl.tech-user.fr";
    $Website_link = "https://ovl.tech-user.fr/";
    ?>