<?php
    $API_link = "https://ovl.tech-user.fr:6969";
    $Website_link = "https://ovl.tech-user.fr:7070";
    ?>